function eta = init(eta0,R,par,sp)
%INIT Initialize or randomize model parameter values.
% Syntax:
%   M = INIT(M0)
%   M = INIT(M0,R,PAR,SP)
%
%   M0: Original model as any IDLTI object (IDPOLY, IDSS, IDTF, IDPROC or IDGREY)
%    M: Modified M0 with new initial parameter values
%    R: variance of random initial parameters
%       (row vector with dim = dimension of parameter vector)
%       A scalar R gives the same variance R to all parameters.
%       Setting R = 0 just stabilizes M0 if that is possible within the
%       parameterization.
%  PAR: Mean of initial parameters (PAR = [] gives default)
%   SP: SP = 'p' : stability of predictor is assured
%       SP = 's' : stability of system is assured
%       SP = 'b' : both predictor and system will be stable
%
%   Defaults: SP = 'p', PAR = the parameter values of M0, R = 1.
%
% See also IDPARAMETRIC/RSAMPLE, IDPARAMETRIC/SIM, FSTAB.

% Note: INIT ignores parameter constraints (Free, Minimum/Maximum) since
% this action is not performed in estimation loop.

%   L. Ljung 10-2-1990,9-26-1993
%   Copyright 1986-2012 The MathWorks, Inc.

ArraySize = getArraySize(eta0);
if prod(ArraySize)>1
   ctrlMsgUtils.error('Ident:general:commandNotSupportedForModelArrays','init')
end
parvec = eta0.ParameterVector;
adv = eta0.Algorithm.Advanced;
Zstab = adv.Threshold.Zstability;
Sstab = adv.Threshold.Sstability;
nd = length(parvec);
Ts = eta0.Ts;
[ny, nu] = size(eta0);
if Ts
   Tstab = Zstab;
else
   Tstab = Sstab;
end
if nargin<2;R=[];end
if nargin<3;par=[];end
if nargin<4;sp=[];end

if isempty(R),
   R = ones(nd,1);
end,
if isempty(sp),
   sp = 'p';
elseif ~ischar(sp) || ~any(strcmpi(sp,{'p','s','b'}))
   ctrlMsgUtils.error('Ident:transformation:initCheck1')
end
if isempty(par),
   par = parvec;
end
par = par(:);
if length(R)==1
   R = R*ones(1,nd);
end

if length(R)~=nd
   ctrlMsgUtils.error('Ident:transformation:initCheck2')
end
if length(par)~=nd
   ctrlMsgUtils.error('Ident:transformation:initCheck3')
end

test = 2; nr = 1;
if norm(R)==0
   noR = 1;
else
   noR = 0;
end

projk = 0; proja = 0;

if isa(eta0,'idss')
   if strcmpi(eta0.SSParameterization,'Free')
      if strcmpi(eta0.DisturbanceModel,'Estimate') && (sp=='b' || sp=='p')
         projk = 1;
      end
      if (sp=='s' || sp=='b') || (strcmpi(eta0.DisturbanceModel,'None') && sp=='p')
         proja = 1;
      end
   end
end

eta = eta0;
while ~isempty(test) && test && nr<200
   parval = diag(sqrt(R))*randn(nd,1)+par;
   eta.ParameterVector = parval;
   if isa(eta0,'idpoly') && (sp=='s' || sp=='b')
      a = eta.a; 
      if ~iscell(a), a = {a}; end
      for ct = 1:ny+1:ny^2
         a{ct} = fstab(a{ct},Ts,Tstab,false);
      end
      
      f = eta.f;
      if ~iscell(f), f = {f}; end
      for ct = 1:numel(f)
         f{ct} = fstab(f{ct},Ts,Tstab,false);
      end
      
      d = eta.d;
      if ~iscell(d), d = {d}; end
      for ct = 1:numel(d)
         d{ct} = fstab(d{ct},Ts,Tstab,false);
      end
      
      eta = set(eta,'a',a,'f',f,'d',d);      
   end
   
   if isa(eta0,'idpoly') && (sp=='p' || sp=='b')
      c = eta.c;
      if ~iscell(c), c = {c}; end
      for ct = 1:numel(c)
         c{ct} = fstab(c{ct},Ts,Tstab,false);
      end
      
      f = eta.f;
      if ~iscell(f), f = {f}; end
      for ct = 1:numel(f)
         f{ct} = fstab(f{ct},Ts,Tstab,false);
      end
      
      eta = set(eta,'c',c,'f',f);      
   end
   
   [a,~,c,~,k] = idssdata(eta);
   if proja
      a = fstab(a,Ts,Tstab,true); eta = set(eta,'a',a);
   end
   
   if projk
       if (Ts && max(abs(eig(a-k*c)))>Zstab) || (~Ts && max(real(eig(a-k*c)))>Sstab)
          [~, k] = idpack.utComputeKalmanGain(a',c',k*k',eye(size(c,1)),k,Ts);
          eta.k = k;
       end
   end
   
   if sp=='s',
      if Ts
         test = max(abs(eig(a)))>Zstab;
      else
         test = max(real(eig(a)))>Sstab;
      end
   elseif sp=='p',
      if Ts
         test = max(abs(eig(a-k*c)))>Zstab;
      else
         test = max(real(eig(a-k*c)))>Sstab;
      end
   else
      if Ts
         test = max([max(abs(eig(a))), max(abs(eig(a-k*c)))])>Zstab;
      else
         test = max([max(real(eig(a))), max(real(eig(a-k*c)))])>Sstab;
      end
   end
   nr = nr+1;
   if nr==200
      ctrlMsgUtils.error('Ident:transformation:stabilizationFailure')
   end
   if noR
      nr = 200;
      if test
         ctrlMsgUtils.warning('Ident:transformation:initUnstablePredictor')
      end
   end
end
